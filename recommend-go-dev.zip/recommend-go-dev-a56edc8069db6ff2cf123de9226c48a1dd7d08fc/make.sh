#!/usr/bin/env bash

if [ ! -f "$0" ]; then
    echo 'make must be run within its container folder' 1>&2
    exit 1
fi

if [ ! -d "$GOROOT" ]; then
	GOROOT="/usr/local/go"
fi

if [ "$1" == "clean" ]; then
	rm bin/* pkg/* utility/pkg/* -rf
	exit
fi

CURDIR=`pwd`
export GOROOT=$GOROOT
export GOPATH="$CURDIR"
echo ${GOPATH}

author=${USER}
date=`date "+%Y-%m-%d_%H:%I:%S"`

goversion=`${GOROOT}/bin/go version`

ldflags="-X recommend/logic._AUTHOR_=$author -X recommend/logic._COMPILETIME_=\"$date\""
echo ldflags ${ldflags}

echo "formating code..."
${GOROOT}/bin/gofmt -w src/recommend

# 以下命令可以使用go get golang.org/x/tools/cmd/goimports获取
goimports -w=true src/recommend

go vet -all -source recommend

echo "building recommend..."
CGO_ENABLED=0 GOOS=linux  GOARCH=amd64 ${GOROOT}/bin/go install -v -ldflags "$ldflags" recommend
#CGO_ENABLED=0 GOOS=darwin GOARCH=amd64 ${GOROOT}/bin/go install -v -ldflags "$ldflags" recommend

if [ -d "src/recommend/tester" ]; then
    echo "building tests..."
    CGO_ENABLED=0 GOOS=linux  GOARCH=amd64 ${GOROOT}/bin/go install -v -ldflags "$ldflags" recommend/tester
    CGO_ENABLED=0 GOOS=darwin GOARCH=amd64 ${GOROOT}/bin/go install -v -ldflags "$ldflags" recommend/tester
fi

if [ "$1" == "test" ] || [ "$2" == "test" ];then
	echo "test";
fi


echo 'finished'
