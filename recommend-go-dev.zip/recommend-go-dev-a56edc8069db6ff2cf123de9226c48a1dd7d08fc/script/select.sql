#live video
select count(vid) from video where 
		parent_category in ('65','55','54','53','47')
		and uid not in ('3512923','3194741','3512978','3083296','3114024','3503710','2584835','2723788','795605','3183159','3194481','3512692','3512781','3194629','3512815','3512803','2952436','3399207','3512804','3512778','3512808','3194554','2692975','3512916','3512979','3085667','3085957','3083188')
		and uptime > '2018-11-02'

#smart video
select count(vid) from video where status = 0 and type=10

#invalid video
select count(vid) from video where (video.status <> 0 or video.uid=0 or video.type=9)
  and video.uptime > '2018-11-02'


#warm(hot) video
SELECT count(vid) FROM video WHERE
  hits_total>2000 and user_hits>1500 and good_total>50 and comment_total>25 and share>25
  and createtime>'2018-08-05'
