#!/bin/bash

ADDR="106.75.17.164:8080"
PARAS=recsid=10001&diu=861601037947820&sid=102&nums=100

curl -k http://${ADDR}/recommend/videos?${PARAS}