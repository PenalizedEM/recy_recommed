#!/bin/bash

tar -cjf rec.tar.bz2 bin/linux_amd64/recommend bin/linux_amd64/tester conf/recommend-test.toml conf/recommend-online.toml
scp -P 12306 rec.tar.bz2 zhangj@106.75.50.203:/tmp

